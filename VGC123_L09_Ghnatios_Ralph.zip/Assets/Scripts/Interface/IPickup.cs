using UnityEngine;

public interface IPickup
{
    public void Pickup(GameObject player);
}
